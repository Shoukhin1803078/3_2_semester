import socket 

HOST='192.168.0.193'

PORT=9999

socket= socket.socket(socket.AF_INET, socket.SOCK_STREAM)
socket.connect((HOST,PORT))

message=input("Enter your Message")

socket.send(message.encode('utf-8'))

print(socket.recv(1024).decode('utf-8'))

